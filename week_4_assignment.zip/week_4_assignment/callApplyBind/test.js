// function greet(greeting,seeoff){
//     console.log(`${greeting} ${this.name} , you are ${this.age} year old ok ${seeoff}`);
    
// }
// // greet();

// let person = {name:"ritik",age:"24"};

// greet.apply(person,["hi","bye"]);

// let greetRitik = greet.bind(person , "hi" , "bye");

// greetRitik();




    function greet(){
        // let  name = "ritik";
        console.log(`hi ${this.name}`);
        
    }
    greet();
let person = {name:"ritik"};

let greetPerson = greet.bind(person);

console.log(greetPerson);

// person.greet();



